/*
 * Balance.h
 *
 *  Created on: 2022��4��25��
 *      Author: asus
 */

#ifndef _BALANCE_H_
#define _BALANCE_H_

extern float Angle_Set,GYROfilter,gyroscope,Angle_Set1;// ���������ǰ�װ�ǶȽ���

extern int16 PWMOut,angleout;
extern int lanyajieshou;

void Kalman_Filter_X(float Accel,float Gyro);

void Kalman_Filter_Y(float Accel,float Gyro);

void PidInit(pid_param_t * pid);

extern int16 SPEED,ASPEED,xianshipwm;

extern float BALANCE_OUT,SPEED_OUT,ANGLE_OUT;

extern float constrain_float(float amt, float low, float high);

void getangle();

void Data_steepest(void);

void Speed_celue();

void Dynamic_Zero_Point(int actuator,int Speed);

void ZERO_Point();

extern float Angle_X_Final,Angle_Y_Final,Angle_x_temp,Angle_y_temp;

extern float GYRO_Real_Y,GYRO_Real_X,GYRO_Real_Z,ACC_Real_Y,ACC_Real_Z,ACC_Real_X;

extern int16 gyr,acc,rgry,ACC,gyro__x,GYRO;

typedef struct
{
    uint8 cnt;

    int32 lst_pow_sum;

    int32 now_out;
    int32 lst_out;
    int32 now_velocity_xdt;
} _steepest_st;



#endif /* CODE_BALANCE_H_ */
