/*
 * init.h
 *
 *  Created on: 2022��3��10��
 *      Author: asus
 */

#ifndef __INIT_H_
#define __INIT_H_


#include "headfile.h"


#define k1 P20_2
#define k2 P21_7
#define k3 P21_2
#define k4 P23_1

#define k5 P21_4
#define k6 P22_3
#define k7 P22_1
#define k8 P22_2
#define k9 P22_0
void All_Init(void);

#endif //__INIT_H__
