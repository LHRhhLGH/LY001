/*
 * servo.h
 *
 *  Created on: 2022��3��10��
 *      Author: asus
 */

#ifndef  SERVO_H
#define  SERVO_H

//*********���**************FTM3_CH0_PIN**//
#define S3010_FTM_CH  ATOM1_CH1_P33_9
#define S3010_HZ    (300)

#define S3010_LEFT 57000   //  ��ֵ57000           2650       //14300  //35805 //37000  //72000   /54005              //8905
#define S3010_MID 45800    //��ֵ45800
#define S3010_RIGHT 33000  //  ��ֵ33000


float range_protect(float duty,float  min, float max);//�޷�����

#endif
