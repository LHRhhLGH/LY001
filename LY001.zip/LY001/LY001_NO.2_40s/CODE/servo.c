/*
 * servo.c
 *
 *  Created on: 2022��3��10��
 *      Author: asus
 */
#include "headfile.h"
#include  "math.h"

float range_protect(float duty,float  min, float max)//�޷�����
{
    if (duty >= max)
    {
        return max;
    }
    else if (duty <= min)
    {
        return min;
    }
    else
    {
        return duty;
    }
}


