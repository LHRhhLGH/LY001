/*
 * my_adc.h
 *
 *  Created on: 2022��3��10��
 *      Author: asus
 */

#ifndef __MY_ADC_H__
#define __MY_ADC_H__

extern int Left ,
       LeftS,
       Leftx,
       Mid ,
       Right,
       RightS,
       Rightx;



void adc_get();
float lowV( float com );

#endif

