/*
 * Balance.c
 *
 *  Created on: 2022��4��25��
 *      Author: asus
 */

    //ֱ��������
#include "headfile.h"

float Dynamic_P=0.8;
int16 PWMOut,angleout;
float Angle_Set=-2.15,Angle_Set1=2.15;//-0.5
float GYROfilter,gyroscope;//�˲�����ٶȻ���� ������ֵ

int lanyajieshou;
    float ANGLE_OUT;
    int16 SPEED,ASPEED,xianshipwm;
    float BALANCE_OUT;
    //�ٶȻ�����
    float SPEED_OUT;
void PidInit(pid_param_t * pid)
{
  pid->Kp        = 0;
  pid->Ki        = 0;
  pid->Kd        = 0;
  pid->imax      = 0;
  pid->out_p     = 0;
  pid->out_i     = 0;
  pid->out_d     = 0;
  pid->out       = 0;
  pid->integrator= 0;
  pid->last_error= 0;
  pid->last_derivative   = 0;
  pid->last_t    = 0;
}
float constrain_float(float amt, float low, float high)
{
  return ((amt)<(low)?(low):((amt)>(high)?(high):(amt)));
}

void Balance_CAR (void)
{
PidInit(&Gyro_PID);     //ֱ���ڻ�������ʼ��
PidInit(&Angle_PID);    //ֱ���⻷������ʼ��
PidInit(&BalSpeed_PID);    //�ٶȻ�������ʼ��
//����
Gyro_PID.Kp = 500;     //600     50  65 //ֱ���ڻ�������ֵ  ���ٶ�
Gyro_PID.Ki = 4.3;//26.4        1.7   2
Gyro_PID.Kd = 0.5;//1
//λ��
 Angle_PID.Kp=2;  //0.964 1.0002    1.41   2.2    //ֱ���⻷������ֵ   �Ƕ�
 Angle_PID.Ki = 0;
 Angle_PID.Kd =1.8;//0.02        1   0.5        2
 //λ��
 BalSpeed_PID.Kp = 0.035; //0.15        //�ٶȻ�������ֵ
 BalSpeed_PID.Ki = 0;
 BalSpeed_PID.Kd = 0.1;/*0.1*/
}


void getangle()
{
    get_icm20602_accdata_spi();
    get_icm20602_gyro_spi();
    Angle_x_temp=(atan2(ACC_Real_Y,ACC_Real_Z)*180/PI);
    Kalman_Filter_X(Angle_x_temp,GYRO_Real_X);
}

float lowV( float com )
{
    static float iLastData;    //��һ��ֵ
    float iData;               //���μ���ֵ
    float dPower = 0.4;               //�˲�ϵ��
    iData = ( com * dPower ) + ( 1 - dPower ) * iLastData; //����
    iLastData = iData;                                     //������������
    return iData;                                         //��������
}

void steepest_descend(int32 arr[],uint8 len,_steepest_st *steepest,uint8 step_num,int32 in)
{
    uint8 updw = 1;//0 dw,1up
    int16 i;
    uint8 step_cnt=0;
    uint8 step_slope_factor=1;
    uint8 on = 1;
    int8 pn = 1;
    float step = 0;
    int32 start_point = 0;
    int32 pow_sum = 0;
    steepest->lst_out = steepest->now_out;
    if( ++(steepest->cnt) >= len )
    {
        (steepest->cnt) = 0; //now
    }
    arr[ (steepest->cnt) ] = in;
    step = (float)(in - steepest->lst_out)/step_num ;//�ݶ�
    if(ABS(step)<1)//��������<1����Ч�ж�
    {
        if(ABS(step)*step_num<2)
        {
            step = 0;
        }
        else
        {
          step = (step > 0) ? 1 : -1;
        }
    }
    start_point = steepest->lst_out;
    do
    {
        for(i=0;i<len;i++)
        {
            pow_sum += my_pow(arr[i] - start_point );// /step_num;//������С����**
        }

        if(pow_sum - steepest->lst_pow_sum > 0)
        {
            if(updw==0)
            {
                on = 0;
            }
            updw = 1;//������
            pn = (pn == 1 )? -1:1;
        }
        else
        {
            updw = 0; //�����½�
            if(step_slope_factor<step_num)
            {
                step_slope_factor++;
            }
        }

        steepest->lst_pow_sum = pow_sum;
        pow_sum = 0;
        start_point += pn *step;//����

        if(++step_cnt > step_num)//���Ƽ������
        {
            on = 0;
        }
    }
    while(on==1);

    steepest->now_out = start_point ;//0.5f *(start_point + steepest->lst_out);//

    steepest->now_velocity_xdt = steepest->now_out - steepest->lst_out;
}
#define MPU_WINDOW_NUM 6
#define MPU_STEEPEST_NUM 6

#define MPU_WINDOW_NUM_ACC 15
#define MPU_STEEPEST_NUM_ACC 15

_steepest_st steepest_ax;
_steepest_st steepest_ay;
_steepest_st steepest_az;
_steepest_st steepest_gx;
_steepest_st steepest_gy;
_steepest_st steepest_gz;

int32 steepest_ax_arr[MPU_WINDOW_NUM_ACC ];
int32 steepest_ay_arr[MPU_WINDOW_NUM_ACC ];
int32 steepest_az_arr[MPU_WINDOW_NUM_ACC ];
int32 steepest_gx_arr[MPU_WINDOW_NUM ];
int32 steepest_gy_arr[MPU_WINDOW_NUM ];
int32 steepest_gz_arr[MPU_WINDOW_NUM ];

float GYRO_Real_Y,GYRO_Real_X,GYRO_Real_Z,ACC_Real_Y,ACC_Real_Z,ACC_Real_X;
int16 gyr,acc,acc_temp,rgry,ACC;
//x,y�ļ��ٶ�ֵ
void Data_steepest(void)
{
    steepest_descend(steepest_gx_arr ,MPU_WINDOW_NUM ,&steepest_gx ,MPU_STEEPEST_NUM,(int32) icm_gyro_x);
    steepest_descend(steepest_gy_arr ,MPU_WINDOW_NUM ,&steepest_gy ,MPU_STEEPEST_NUM,(int32) icm_gyro_y);
        steepest_descend(steepest_gz_arr ,MPU_WINDOW_NUM ,&steepest_gz ,MPU_STEEPEST_NUM,(int32) icm_gyro_z);
    steepest_descend(steepest_ax_arr ,MPU_WINDOW_NUM_ACC ,&steepest_ax ,MPU_STEEPEST_NUM_ACC,(int32) icm_acc_x);
    steepest_descend(steepest_ay_arr ,MPU_WINDOW_NUM_ACC ,&steepest_ay ,MPU_STEEPEST_NUM_ACC,(int32) icm_acc_y);
        steepest_descend(steepest_az_arr ,MPU_WINDOW_NUM_ACC ,&steepest_az ,MPU_STEEPEST_NUM_ACC,(int32) icm_acc_z);
    GYRO_Real_X = steepest_gx.now_out *0.061f;
    if(GYRO_Real_X>0)GYRO_Real_X-=0.8845;
    if(GYRO_Real_X<0)GYRO_Real_X+=0.8845;
    if(GYRO_Real_X>0&&GYRO_Real_X<0.0305)GYRO_Real_X=0;//0.0609
    if(GYRO_Real_X<0&&GYRO_Real_X>-0.0305)GYRO_Real_X=0;
//    if((GYRO_Real_X<-0.1218&&GYRO_Real_X>-0.1219))GYRO_Real_X=0;
    GYRO_Real_Y = steepest_gy.now_out *0.0610f;
        GYRO_Real_Z = steepest_gz.now_out *0.0610f;
        ACC_Real_X = steepest_ax.now_out *2.3926f ;
        ACC_Real_Y = steepest_ay.now_out *2.3926f ;
        ACC_Real_Z = steepest_az.now_out *2.3926f ;
        gyr =     GYRO_Real_X*100+500;
        rgry=gyro__x*100+200;
//        PWMOut = GYROfilter;
        gyroscope=lowV(GYRO_Real_X);
}
//����������
float Angle_X_Final;
float angleAy,gyroGx;
float Q_angle=0.001;               /*  �Լ��ٶȼƵ�����ָ�� */
float Q_gyro=0.003;                /*  �������ǵ�����ָ��   */
float R_angle=0.5;                 /*   ���������е����    */
float dt=0.005;                    /*       ����ʱ��         */
char  C_0     = 1;
float Q_bias, Angle_err;
float PCt_0, PCt_1, E;
float K_0, K_1, t_0, t_1;
float Pdot[4] ={0,0,0,0};
float PP[2][2] = { { 1, 0 },{ 0, 1 } };
float   Gyroy;
float Angle_Y_Final;
float Angle_x_temp,Angle_y_temp;
void Kalman_Filter_X(float Accel,float Gyro) //����������
{

    Angle_X_Final += (Gyro - Q_bias) * dt; //�������

    Pdot[0]=Q_angle - PP[0][1] - PP[1][0]; // Pk-����������Э�����΢��

    Pdot[1]= -PP[1][1];
    Pdot[2]= -PP[1][1];
    Pdot[3]= Q_gyro;

    PP[0][0] += Pdot[0] * dt;   // Pk-����������Э����΢�ֵĻ���
    PP[0][1] += Pdot[1] * dt;   // =����������Э����
    PP[1][0] += Pdot[2] * dt;
    PP[1][1] += Pdot[3] * dt;


    PCt_0 = C_0 * PP[0][0];
    PCt_1 = C_0 * PP[1][0];

    E = R_angle + C_0 * PCt_0;

    K_0 = PCt_0 / E;
    K_1 = PCt_1 / E;

    Angle_err = Accel - Angle_X_Final;  //zk-�������
    Angle_X_Final += K_0 * Angle_err;    //�������
    Q_bias        += K_1 * Angle_err;    //�������
    gyro__x   = Gyro - Q_bias;  //���ֵ��������ƣ���΢�� = ���ٶ�

    t_0 = PCt_0;
    t_1 = C_0 * PP[0][1];

    PP[0][0] -= K_0 * t_0;       //����������Э����
    PP[0][1] -= K_0 * t_1;
    PP[1][0] -= K_1 * t_0;
    PP[1][1] -= K_1 * t_1;

 acc= Angle_X_Final*10+200;

}

void Speed_celue()
{
    if((HDflag==0||HDflag==1)/*���л����Ͳ��ڻ�����*/&&(end_l>15||end_r>15||end_l<=5||end_r<=5)/*���*/&&(SC_flag==0))
    {
        speed = -14;
    }
    else if((HDflag==2||HDflag==3||HDflag==4||HDflag==5||HDflag==6)||SC_flag==1)
    {
        speed = -13;
    }
    else if((end_r>8&&end_r<15)&&(end_l>8&&end_l<15))
    {
//        Angle_Set = 5;
        speed = -15;
    }
//    else if(end_l>5&&end_l<20&&(end_r>30||end_r<=5))
//    {
////        Angle_Set = -4.85;
//        speed = -10;
//    }
//
//    else if((HDflag==1||HDflag==2||HDflag==3||HDflag==4))
//        {
//    //        Angle_Set = -4.85;
//            speed = -13;
//        }
//
//    else if((end_r==10&&end_l==10)||(end_r<20&&end_l<20)||((end_r<=5&&end_l<=5)&&(HDflag==0&&SC_flag==0)))
//    {
//        speed = -17;
//    }
}

void Dynamic_Zero_Point(int actuator,int Speed)
{
    if((S3010_MID-20)<eleOut||(S3010_MID+20)>eleOut)
    {
        Angle_Set1 = Dynamic_P*(actuator - S3010_MID) /3000+Angle_Set;//(57000-45800)/300 11200
    }

}

void ZERO_Point()
{
    if(eleOut>51000)
    {
        Angle_Set1 = 0;
    }
    else if(eleOut<38200)
    {
        Angle_Set1 = 4.3;
    }
}
