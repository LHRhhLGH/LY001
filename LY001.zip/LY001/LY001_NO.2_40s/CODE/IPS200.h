/*
 * IPS200.h
 *
 *  Created on: 2022��4��25��
 *      Author: asus
 */

#ifndef _IPS200_H_
#define _IPS200_H_


void display();
void tuxiangxianshi();


#endif /* CODE_IPS200_H_ */
