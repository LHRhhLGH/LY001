/*
 * 001.h
 *
 *  Created on: 2022��5��21��
 *      Author: asus
 */

#ifndef _001_H_
#define _001_H_

#include<math.h>

#define THERSHOLD 180

void  sideline_40_20(void);

void Image_Get(void);


uint8 abss(uint8 a,uint8 b);

unsigned char cmere_find_bottom_line(uint8 num);

void cmere_find_line();

void newhaha(void);

uint16 abssF(uint16 a,uint16 b); //0�Ǻ�

char Upward1();

char Upward2();

char Upward3();

char Upward4();

char Upward5();

char Upward6();

char Upward7();

void saidaocelue();

extern int Forkflag,HD1,HD2,HDX,HDflag,DEPART,shizi,Horizontally_Down,CK_flag,Carving,Law_maker;

extern int32 sudujiang;

extern unsigned char flgsss,diuxianzuo,diuxianyou;

extern unsigned char new_x,new_y,flex_L,flex_R,LH,RR,Hammer;

extern unsigned char result[120][188];

extern unsigned char   line_left[57];

extern float  line_mid[57];

extern double xielv_left ,xielv_right,xielv_left1 ,xielv_right1,xielv_left2,xielv_right2;

extern unsigned char  line_right[57];

uint16  crossroads_enhance(uint8 in_x,uint8 in_y);

uint8 Difference(uint8 y,uint8 x);

uint8 Difference_bottom(uint8 y,uint8 x);

unsigned char line_text(unsigned char in_y,unsigned char in_x,unsigned char in_long);

extern unsigned char dibiandiuxianzuo,dibiandiuxianyou,dibiandiuxianzuo1,dibiandiuxianyou1,yizhi;

uint8  the_max( int a);

//void Blown_Bike();

void SPEED_Change(uint8 mode,float set_speed,float add_speed);

extern int aaaaa,shuaxin,shuaxinlv,start_x;

extern unsigned int yuzhi,yuzhi1,yuzhi2,yuzhi3,start_l,start_r,Limit,huanhe,Limit2;

extern unsigned char Image_Datanewhaha[60][94];

extern uint8 end_l,end_r,lose_differ,end_l1,end_r1;

extern unsigned char image_L[60][94];

extern unsigned char result_clean,sb;

extern float Point_right,Point_left,Point_mid;

extern int SC_M,SC_L1,SC_R1,SC_L2,SC_R2,SC_flag;

//void ZC();
float ZC();

#define MIDVALUE 46.5//94  92   //���������ĸ�������

#define LEFTVALUE 22.5

#define RIGHTVALUE 66

#define RIGHTVALUE1 70

#define LEFT 1

#define RIGHT 2

#define DOUBLE 3

#define LINE_NULL 4

#define LEFT1 5

#define RIGHT1 6

#define RIGHT2 7

#define SUB 0

#define ADD 1

#define SEARCH_lINE_START 57//���������������

#define END_LINE_TEXT_Y 5//���߲���������

#define BRODER_L 2 // 3  4  8

#define BRODER_R 91// 184 183

#define DXH_L 30// 184 183
#define DXH_R 30// 184 183

#endif /* CODE_001_H_ */
