/*
 * my_adc.c
 *
 *  Created on: 2022��3��10��
 *      Author: asus
 */
#include "headfile.h"

uint16 LeftADC1,MidADC1,RightADC1;
int Left = 0,
       LeftS=0;
       Leftx = 0,
       Mid = 0,
       Right = 0,
       RightS=0;
       Rightx = 0;
void adc_get()//����a6  ����a2 ��бa7 ��бa5
{
    Left = adc_convert(ADC_0,ADC0_CH0_A0 , ADC_12BIT);//��
    LeftS = adc_convert(ADC_0,ADC0_CH6_A6 , ADC_12BIT);//��
    Leftx = adc_convert(ADC_0,ADC0_CH7_A7 , ADC_12BIT);//��б
    Mid = adc_convert(ADC_0,ADC0_CH1_A1, ADC_12BIT);//��
    Right =  adc_convert(ADC_0,ADC0_CH4_A4, ADC_12BIT);//��
    RightS =  adc_convert(ADC_0,ADC0_CH2_A2, ADC_12BIT);//��
    Rightx =  adc_convert(ADC_0,ADC0_CH5_A5, ADC_12BIT);//��б

}


