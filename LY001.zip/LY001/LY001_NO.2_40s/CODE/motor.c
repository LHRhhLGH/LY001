/*
 * motor.c
 *
 *  Created on: 2022��3��9��
 *      Author: asus
 */

#include "headfile.h"
#include "common.h"
#include "math.h"
#include "isr.h"

float   MOTOR_Duty;
float   MOTOR_Speed = 0;         //FTM1  ��ֵ
float   DMOTOR_Duty;
float   DMOTOR_Speed = 0;         //FTM1  ��ֵ

unsigned char Flag_Stop = 0;
float   Integration;
int16 Speed,Left_High_Speed,jijuflag;

/******** ������� *********/
#define MOTOR_MAX  5000
#define DMOTOR_MAX  9600
//#define MOTOR_MIN  -5000
int32 aaa,bbb,ddd,eee,jijusheng,fff;
void MOTOR_Control(void)
{
    if(Angle_X_Final > 25||Angle_X_Final <-25)
    {
        speed=0;
    }
     Left_High_Speed = speed;//150-12-1.5
////    if(midADC1 < 110)    //�ж��ǲ��ǳ�����  20 10 10
////    {
////        speed = 0;
////    }
         bbb-=MOTOR_Speed;
    MOTOR_Speed = gpt12_get(GPT12_T2);
//
    if(HDflag==6)
    {
        jijuflag=1;
    }
    if(Law_maker==9)
    {
        eee-=MOTOR_Speed;
    }
    if(Hammer==2)
    {
        fff-=MOTOR_Speed;
    }
    jijusheng=eee;
     MOTOR_Duty  += -PID_Realize(&MOTOR_Speed_PID, MOTOR_Speed, Left_High_Speed);//ʹ�ô�������ʽPID���е���
    if (MOTOR_Duty>0)
              {
                  MOTOR_Duty = range_protect(MOTOR_Duty, 0, MOTOR_MAX);   //�޷�����
                //�����ת
                  pwm_duty(ATOM0_CH6_P23_1,MOTOR_Duty);
                  gpio_set(P32_4, 1);//����
              }
     else
              {
                  MOTOR_Duty = range_protect(MOTOR_Duty, -MOTOR_MAX,0);
                //�����ת
                  pwm_duty(ATOM0_CH6_P23_1,-MOTOR_Duty);
                  gpio_set(P32_4, 0);//����
              }
    gpt12_clear(GPT12_T2);
   }

/******** ֱ������ *********/
int PWM_X,PWM_accel,DUTY;
void Balance(void)
{
    /* ��ȡ������ֵ */
    DMOTOR_Speed = gpt12_get(GPT12_T6); // ���ַ���     ĸ�������2
//    DMOTOR_Duty = (PWM_X);
    DMOTOR_Duty =- BALANCE_OUT;
    xianshipwm = DMOTOR_Duty/9;
    if(DMOTOR_Duty>9600) DMOTOR_Duty=9600;        // �����ֵ���޷�
    else if(DMOTOR_Duty<-9600) DMOTOR_Duty=-9600; // �����ֵ���޷�
    else if(DMOTOR_Duty<-0) DMOTOR_Duty -=400;    // ����
    else if(DMOTOR_Duty>0) DMOTOR_Duty+=400;      // ����
    if((DMOTOR_Duty<600)&&(DMOTOR_Duty>-600))
            DMOTOR_Duty=0;

    if((Angle_X_Final > 15))       // ˤ��ͣ���ж�

    {
        DMOTOR_Duty = 0;
    }
    else if((Angle_X_Final < -15))
    {
        DMOTOR_Duty = -0;
    }    else if(lanyajieshou==3)
    {
     speed=0;

         DMOTOR_Duty = 0;
    }
    DUTY=DMOTOR_Duty;

//    MotorCtrl(MotorDutyA,0);       // �������
    if (DMOTOR_Duty>0)
              {
                  DMOTOR_Duty = range_protect(DMOTOR_Duty, 0, DMOTOR_MAX);   //�޷�����
                //�����ת
                  pwm_duty(ATOM0_CH0_P21_2,DMOTOR_Duty);
                  gpio_set(P21_3, 1);//����
              }
     else
              {
                  DMOTOR_Duty = range_protect(DMOTOR_Duty, -DMOTOR_MAX,0);
                //�����ת
                  pwm_duty(ATOM0_CH0_P21_2,-DMOTOR_Duty);
                  gpio_set(P21_3, 0);//����
              }
    gpt12_clear(GPT12_T6);
}
