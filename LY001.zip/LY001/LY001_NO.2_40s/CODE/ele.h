/*
 * ele.h
 *
 *  Created on: 2022��3��9��
 *      Author: asus
 */

#ifndef _ELE_H_
#define _ELE_H_

extern float    Point;
extern int32   eleOut,num,duoji;//�������
extern float   elefValue,elemid ,Point_Mid;
extern int Set;
int32 KalmanFilter(int32 ResrcData);
float PlacePID_Control();
void DirectionControl() ;
void Champion();
void PIDcelue();
void Bluetooth();//����
extern int16 speed;
#endif
