/*
 * IPS200.c
 *
 *  Created on: 2022��4��25��
 *      Author: asus
 */

#include "headfile.h"

void display()
{
   ips200_showstr(0,0,"MOTOR_Duty",NORMAL);
   ips200_showfloat(100 ,1,DMOTOR_Duty,5,5);
   ips200_showstr(0,2,"MOTOR_Speed",NORMAL);
   ips200_showstr(100,2,"DMOTOR_Speed",NORMAL);
   ips200_showfloat(0,3,bbb,5,1);
   ips200_showfloat(100,3,DMOTOR_Speed,4,3);
   ips200_showfloat(100,8,Angle_Set1,4,3);
//        ips200_showint16(0,7,icm_gyro_x);
//        ips200_showint16(0,8,icm_gyro_y);
//        ips200_showint16(0,9,icm_gyro_z);
   ips200_showstr(0,9,"Angle_X_Final",NORMAL);
   ips200_showfloat(100,9,Angle_X_Final,4,3);
   ips200_showstr(0, 10, "ANGLE_OUT: ",NORMAL);
   ips200_showfloat(100,10,ANGLE_OUT,3,4);
   ips200_showstr(0, 11, "GYRO_Real_X: ",NORMAL);
   ips200_showfloat(100,11,GYRO_Real_X,3,4);

}

void tuxiangxianshi()
{
    for(int y = 8;y< 57/*68*/;y ++)
    {
//                 //   line_mid[y] = (line_right[y]+line_left[y])/2;//�ϳ�����
        if(line_right[y]!=0)
        {
             ips200_drawpoint(line_right[y]*2,y*2,BLUE);
             ips200_drawpoint((line_right[y])*2+1,y*2,BLUE);
             ips200_drawpoint((line_right[y])*2-1,y*2,BLUE);

        }
        if(line_left[y]!=0)
        {
            ips200_drawpoint(line_left[y]*2,y*2,GREEN);
            ips200_drawpoint((line_left[y])*2+1,y*2,GREEN);
            ips200_drawpoint((line_left[y])*2-1,y*2,GREEN);
        }
        if(line_mid[y]!=0)
       {
           ips200_drawpoint(line_mid[y]*2,y*2,RED);
           ips200_drawpoint(line_mid[y]*2+1,y*2,RED);
           ips200_drawpoint(line_mid[y]*2-1,y*2,RED);
       }
    }

     for(uint16 x = 227-48;x < 233-48;x ++)//��ʾ����y����Զ�ĵ�
      {
         ips200_drawpoint(x,end_r*2+1,PINK);
         ips200_drawpoint(x,end_r*2-1,PINK);
         ips200_drawpoint(x,end_r*2,PINK);
      }
     for(uint16 x = 53-48;x < 59-48;x ++)//��ʾ����y����Զ�ĵ�
      {
         ips200_drawpoint(x,end_l*2+1,GREEN);
         ips200_drawpoint(x,end_l*2,GREEN);
         ips200_drawpoint(x,end_l*2-1,GREEN);
      }
     for(uint16 x = 53-48;x < 59-48;x ++)//��ʾ����y����ĵ�
    {
       ips200_drawpoint(x,flgsss*2+1,GRAY);
       ips200_drawpoint(x,flgsss*2,GRAY);
       ips200_drawpoint(x,flgsss*2-1,GRAY);
    }
//             for(uint16 x = 53-48;x < 59-48;x ++)//��ʾ����y����ĵ�
//                 {
//                    ips200_drawpoint(x,flgsss*2+1,GRAY);
//                    ips200_drawpoint(x,flgsss*2,GRAY);
//                    ips200_drawpoint(x,flgsss*2-1,GRAY);
//                 }
//                 for(int y = 6;y< 118;y ++)//����ͷ����
//         {
//              ips200_drawpoint(94,y,WHITE);
//         }

//                                                     for(int y = 6;y< 118;y ++)//����ͷ����
//                                              {
//                                                   ips200_drawpoint(88,y,WHITE);
//                                              }
//                                                     for(int y = 6;y< 118;y ++)//����ͷ����
//                                               {
//                                                    ips200_drawpoint(100,y,WHITE);
//                                               }

//                 for(int x=0;x<188;x++)
//                 {
//                     ips200_drawpoint(x,20,WHITE);
//                 }
//                 ips200_showfloat(100,12,line_left[42],3,4);
//                 ips200_showfloat(100,13,line_left[43],3,4);
//                 ips200_showfloat(100,14,line_right[42],3,4);
//                 ips200_showfloat(100,15,line_right[42],3,4);

}


